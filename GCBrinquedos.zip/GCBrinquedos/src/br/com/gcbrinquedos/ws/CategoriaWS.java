package br.com.gcbrinquedos.ws;

public class CategoriaWS {
	
	//categoria.dao

}
